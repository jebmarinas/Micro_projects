/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-I11
 */

#ifndef xconfig_mutex__
#define xconfig_mutex__



#endif /* xconfig_mutex__ */ 
