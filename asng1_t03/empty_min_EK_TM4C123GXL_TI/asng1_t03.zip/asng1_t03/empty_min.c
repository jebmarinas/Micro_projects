/*
 * Copyright (c) 2015, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "inc/tm4c123gh6pm.h"
#include <stdbool.h>
#include <stdint.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_adc.h"
#include "inc/hw_types.h"
#include "inc/hw_udma.h"
#include "driverlib/adc.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/timer.h"
#include "driverlib/uart.h"
#include "driverlib/udma.h"
#include "utils/uartstdio.h"
#include "driverlib/i2c.h"
#include <xdc/std.h>
#include <ti/sysbios/BIOS.h>
#include <xdc/cfg/global.h>
#include <ti/sysbios/knl/Task.h>

/*
 *  ======== empty_min.c ========
 */
/* XDCtools Header files */
#include <xdc/std.h>

/* BIOS Header files */
#include <ti/sysbios/BIOS.h>
#include <ti/sysbios/knl/Task.h>

/* TI-RTOS Header files */
#include <ti/drivers/GPIO.h>
// #include <ti/drivers/I2C.h>
// #include <ti/drivers/SDSPI.h>
// #include <ti/drivers/SPI.h>
// #include <ti/drivers/UART.h>
// #include <ti/drivers/Watchdog.h>
// #include <ti/drivers/WiFi.h>

/* Board Header file */
#include "Board.h"

#define TASKSTACKSIZE   512

int global_timer = 0;
uint32_t adc_register_values[1];

Task_Struct task0Struct;
Char task0Stack[TASKSTACKSIZE];

/*
 *  ======== heartBeatFxn ========
 *  Toggle the Board_LED0. The Task_sleep is determined by arg0 which
 *  is configured for the heartBeat Task instance.
 */
Void heartBeatFxn(UArg arg0, UArg arg1)
{
    while (1) {
        Task_sleep((UInt)arg0);
        GPIO_toggle(Board_LED0);
    }
}

/*
 *  ======== main ========
 */
void ConfigurePWM(void) // this will generate pwm signal
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_PWM1);//Enables the pwm
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);// enables the gpiof
    GPIOPinConfigure(GPIO_PF3_M1PWM7);//configures the pwm
    GPIOPinTypePWM(GPIO_PORTF_BASE,GPIO_PIN_3);// this send the port signal for the pwm

    PWMGenConfigure(PWM1_BASE, PWM_GEN_3, PWM_GEN_MODE_DOWN|PWM_GEN_MODE_NO_SYNC);
    PWMGenPeriodSet(PWM1_BASE, PWM_GEN_3,(SysCtlClockGet()/10000)-1);// This will give the period
    PWMPulseWidthSet(PWM1_BASE, PWM_OUT_7,100); // will control the duty cycle
    PWMGenEnable(PWM1_BASE, PWM_GEN_3);// this will enable the module
    PWMOutputState(PWM1_BASE, PWM_OUT_7, true);// this will enable the output


}
void ConfigureHeartBeat(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);// enables the gpiof
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1);
}
void PushButton(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
    GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_4, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
}
void hardware_interrupt_timer(void)
{
    TimerIntClear(TIMER2_BASE,TIMER_TIMA_TIMEOUT);//when it Reaches 1ms clears the interrupt
    global_timer++;
    if(global_timer == 5)
    {
        Semaphore_post(adc_trigger);
    }
    else if(global_timer == 10)
    {
        Semaphore_post(uart_trigger);
    }
    else if(global_timer == 15);
    {
        Semaphore_post(button_trigger);
        global_timer = 0;
    }
}
void adc_handler(void)
{
    while(1)
    {
        Semaphore_pend(adc_trigger,BIOS_WAIT_FOREVER);
        ADCProcessorTrigger(ADC0_BASE, 0);
        while(!ADCIntStatus(ADC0_BASE, 0, false)){};
            ADCIntClear(ADC0_BASE, 0);

            ADCSequenceDataGet(ADC0_BASE, 0,adc_register_values);
    }
}
void uart_handler(void)
{
    while(1)
    {
        Semaphore_pend(uart_trigger,BIOS_WAIT_FOREVER);
        UARTprintf("ADC REGISTER VALUES%d:\n",adc_register_values);
    }
}
void button_handler(void)
{
    while(1)
    {
        Semaphore_pend(button_trigger,BIOS_WAIT_FOREVER);
        GPIOPinTypePWM(PWM0_BASE, PWM0_ENABLE_R);
        // IF PRESSED UPDATE PWM SIGNAL
    }
}
void ConfigureUART(void){

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);


    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);


    UARTStdioConfig(0, 115200, SysCtlClockGet());
}

void ConfigureADC(void){



        ADCIntDisable(ADC0_BASE, 0);

        ADCSequenceDisable(ADC0_BASE, 0);

        ADCSequenceConfigure(ADC0_BASE, 0, ADC_TRIGGER_PROCESSOR, 0);

        ADCSequenceStepConfigure(ADC0_BASE, 0, 0, ADC_CTL_CH4 | ADC_CTL_END |
                                 ADC_CTL_IE);

        ADCSequenceEnable(ADC0_BASE, 0);
        ADCIntClear(ADC0_BASE, 0);



}
int main(void)
{
    Task_Params taskParams;

    /* Call board init functions */
    Board_initGeneral();
    Board_initGPIO();
    // Board_initI2C();
    // Board_initSDSPI();
    // Board_initSPI();
    // Board_initUART();
    // Board_initUSB(Board_USBDEVICE);
    // Board_initWatchdog();
    // Board_initWiFi();
//CALL CONFIGURE FUNCTIONS IN MAIN
    Task_Params_init(&taskParams);
    taskParams.arg0 = 1000;
    taskParams.stackSize = TASKSTACKSIZE;
    taskParams.stack = &task0Stack;
    Task_construct(&task0Struct, (Task_FuncPtr)heartBeatFxn, &taskParams, NULL);

    /* Turn on user LED  */
    GPIO_write(Board_LED0, Board_LED_ON);


    /* Start BIOS */
    BIOS_start();

    return (0);
}
