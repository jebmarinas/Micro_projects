/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-I11
 */

#ifndef xconfig_empty_min__
#define xconfig_empty_min__



#endif /* xconfig_empty_min__ */ 
